---
'fingerprint-pro-server-api-openapi': patch
---

**visitors**: Test patch