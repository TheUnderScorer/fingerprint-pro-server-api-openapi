---
'fingerprint-pro-server-api-openapi': minor
---

Test minor change
