---
'fingerprint-pro-server-api-openapi': minor
---

Minor change
