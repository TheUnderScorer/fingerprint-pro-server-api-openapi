---
'fingerprint-pro-server-api-openapi': minor
---

Added minor change
