---
'fingerprint-pro-server-api-openapi': patch
---

Patch change test
