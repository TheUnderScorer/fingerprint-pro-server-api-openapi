---
'fingerprint-pro-server-api-openapi': patch
---

Test patch change
