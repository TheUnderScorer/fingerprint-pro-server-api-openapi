---
'fingerprint-pro-server-api-openapi': minor
---

Another minor change
