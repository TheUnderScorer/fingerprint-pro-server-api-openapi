---
'fingerprint-pro-server-api-openapi': minor
---

**visitors**: Test minor