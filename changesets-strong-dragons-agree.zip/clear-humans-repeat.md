---
'fingerprint-pro-server-api-openapi': patch
---

**events**: Test patch