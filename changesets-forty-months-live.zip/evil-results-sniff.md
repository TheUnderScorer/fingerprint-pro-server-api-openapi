---
'fingerprint-pro-server-api-openapi': minor
---

**events**: Test minor change