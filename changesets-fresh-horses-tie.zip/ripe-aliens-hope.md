---
'fingerprint-pro-server-api-openapi': minor
---

**webhook**: Minor change