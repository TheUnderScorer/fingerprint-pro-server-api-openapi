---
'fingerprint-pro-server-api-openapi': minor
---

Minor chanfge
